class Contact < ActiveRecord::Base
  self.table_name = "salesforce.contact"
  
end
