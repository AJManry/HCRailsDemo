class Triggerlog < ActiveRecord::Base
  self.table_name = "salesforce._trigger_log"
  
end
